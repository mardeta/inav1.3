#pragma once

typedef uint8_t rccPeriphTag_t;

